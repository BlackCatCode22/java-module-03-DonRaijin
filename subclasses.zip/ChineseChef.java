public class ChineseChef extends Chef {

    public void makesFriedRice(){
        System.out.println("The chef makes fried rice");

        }
    }

