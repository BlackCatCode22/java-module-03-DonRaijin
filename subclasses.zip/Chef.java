public class Chef {
    public void makeChicken(){
        System.out.println("The chef makes delicious chicken");
    }
    public void makeSalad(){
        System.out.println("The chef makes a healthy salad");
    }
    public void makeSpecialDish(){
        System.out.println("The chef makes bbq ribs");
    }
}
