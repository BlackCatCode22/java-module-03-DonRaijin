public class ItalianChef {
    public void makeChicken(){
        System.out.println("The chef makes delicious chicken");
    }
    public void makeSalad(){
        System.out.println("The chef makes a healthy salad");
    }
    public void makeSpecialDish(){
        System.out.println("The chef makes egg parm");
    }
    public void makePasta(){
        System.out.println("The chef makes pasta");
    }
}
