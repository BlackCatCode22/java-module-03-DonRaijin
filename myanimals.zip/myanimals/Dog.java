package myanimals;

public class Dog extends Animal{

    public static final int MAX_ENERGY = 10;
    private static int dogCount = 0;
    String name;

    int age;

    int energyRemaining;

    public void bark() {
        System.out.println("Woof");
}

    public Dog() {
        dogCount++;
        energyRemaining = MAX_ENERGY;
        addAnimal();
        System.out.println("New Dog created. Total dogs: " + dogCount);
    }

    public static int getDogCount() {
        return dogCount;
    }

    public static int getDogcount() {
        return dogCount;
    }
}

