package myanimals;

//
// dB 9/17/25
public class Animal {

    private static int numOfAnimals = 0;

    // Called by Cat and Dog
    protected void addAnimal() {
        numOfAnimals++;
        System.out.println("Total animals: " + numOfAnimals);
    }

    // Getter for total animal count
    public static int getNumOfAnimals() {
        return numOfAnimals;
    }
    public static void main(String[] args) {

        Cat myCat = new Cat();
        myCat.meow();
        myCat.name = "Athena";
        myCat.age = 8;

        System.out.println(Cat.MAX_LIVES);
        System.out.println(myCat.getCatCount());

        Dog myDog = new Dog();
        myDog.bark();
        myDog.name = "Mochi";
        myDog.age = 5;

        System.out.println(Dog.MAX_ENERGY);
        System.out.println(myDog.getDogCount());
        System.out.println("Final total number of animals: " + getNumOfAnimals());
        }
    }
