package p1;

public class Phone {
    String typeOfPhone;
}
