package p1;

public class CoffeeCup {
    String sizeInOz;
}